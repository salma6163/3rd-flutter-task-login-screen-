// ignore_for_file: sort_child_properties_last, prefer_const_constructors

import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      home: Scaffold(
        backgroundColor: Color(0xff084c6d),
        appBar: AppBar(
          title: const Text(
            "2nd flutter project",
            style: TextStyle(fontSize: 10, color: Colors.white),
          ),
          backgroundColor: Color(0xff084c6d),
        ),
        body: SafeArea(
          child: Center(
            child: ListView(
              children: [
                const Icon(
                  Icons.lock,
                  size: 100,
                  color: Colors.blueGrey,
                ),
                Center(
                  child: Text(
                    "Create Account",
                    style: TextStyle(
                        fontSize: 20, color: Colors.white.withOpacity(.5)),
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 25),
                  child: TextFormField(
                    showCursor: true,
                    decoration: InputDecoration(
                      labelStyle: TextStyle(color: Colors.white, fontSize: 20),
                      hintStyle: TextStyle(
                          color: Color.fromARGB(255, 227, 222, 222)
                              .withOpacity(.5),
                          fontSize: 10),
                      labelText: "Full Name",
                      hintText:
                      "enter your name", //write on it not remove or delete
                      icon: Icon(
                        Icons.person,
                        color: Colors.white70,
                        size: 30,
                      ),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 25),
                  child: TextFormField(
                    showCursor: true,
                    decoration: InputDecoration(
                      labelStyle: TextStyle(color: Colors.white, fontSize: 20),
                      hintStyle: TextStyle(
                          color: Color.fromARGB(255, 227, 222, 222)
                              .withOpacity(.5),
                          fontSize: 10),
                      labelText: "Phone number",
                      hintText:
                      "enter your phone number", //write on it not remove or delete
                      icon: Icon(
                        Icons.phone,
                        color: Colors.white70,
                        size: 30,
                      ),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 25),
                  child: TextFormField(
                    showCursor: true,
                    decoration: InputDecoration(
                      labelStyle: TextStyle(color: Colors.white, fontSize: 20),
                      hintStyle: TextStyle(
                          color: Color.fromARGB(255, 227, 222, 222)
                              .withOpacity(.5),
                          fontSize: 10),
                      labelText: "Email",
                      hintText:
                      "enter your email", //write on it not remove or delete
                      icon: Icon(
                        Icons.email,
                        color: Colors.white70,
                        size: 30,
                      ),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 25),
                  child: TextFormField(
                    obscureText: true,
                    showCursor: true,
                    decoration: InputDecoration(
                      labelStyle: TextStyle(color: Colors.white, fontSize: 20),
                      hintStyle: TextStyle(
                          color: Color.fromARGB(255, 227, 222, 222)
                              .withOpacity(.5),
                          fontSize: 10),
                      labelText: "Email password",
                      hintText:
                      "enter password", //write on it not remove or delete
                      icon: Icon(
                        Icons.password,
                        color: Colors.white70,
                        size: 30,
                      ),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 25),
                  child: TextFormField(
                    obscureText: true,
                    showCursor: true,
                    decoration: InputDecoration(
                      labelStyle: TextStyle(color: Colors.white, fontSize: 20),
                      hintStyle: TextStyle(
                          color: Color.fromARGB(255, 227, 222, 222)
                              .withOpacity(.5),
                          fontSize: 10),
                      labelText: "Confirm Password",
                      hintText:
                      "rewrite password", //write on it not remove or delete
                      icon: Icon(
                        Icons.lock,
                        color: Colors.white70,
                        size: 30,
                      ),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 30,
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 25),
                  child: ElevatedButton(
                    onPressed: () {},
                    child: const Text(
                      "Sign Up",
                      style: TextStyle(
                        fontSize: 20,
                        color: Color.fromARGB(255, 21, 1, 1),
                        //backgroundColor: Colors.grey,
                      ),
                    ),
                    style: TextButton.styleFrom(
                        padding: const EdgeInsets.fromLTRB(70, 10, 70, 10),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30))),
                  ),
                ),
                const SizedBox(
                  height: 30,
                ),
                Padding(
                  padding: EdgeInsets.fromLTRB(72, 0, 72, 0),
                  child: Row(
                    children: [
                      Expanded(
                        child: Row(
                          children: [
                            Text(
                              "Already have an account!?",
                              style: TextStyle(
                                  fontSize: 15,
                                  color: Colors.black.withOpacity(.5)),
                            ),
                          ],
                        ),
                      ),
                      TextButton(
                        onPressed: () {},
                        child: Text(
                          "Sign in",
                          style: TextStyle(
                            fontSize: 20,
                            color: Colors.white.withOpacity(.5),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
